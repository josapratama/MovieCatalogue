# Movie Catalogue - Catatan Submission

## Fitur Utama

1. **List Movie (Home)** — Menampilkan daftar film populer dari TheMovieDB API dengan shimmer loading effect
2. **Detail Movie** — Detail film lengkap: backdrop, poster, rating, jumlah vote, tanggal rilis, bahasa, overview, dan tombol favorite
3. **Favorite Movie** — Menyimpan dan menampilkan film favorit menggunakan Room Database (Dynamic Feature Module)

## Saran yang Diterapkan

### ✅ 1. Tampilan Aplikasi Menarik

- Material Design Components (MaterialCardView, CollapsingToolbarLayout, FAB, BottomNavigationView)
- Shimmer loading effect pada halaman list
- Gradient overlay pada backdrop di detail
- Warna konsisten menggunakan colors.xml
- Margin, padding, dan ukuran komponen sesuai standar

### ✅ 2. Fitur Tambahan — Search

- Halaman Search dengan debounce 500ms menggunakan `StateFlow` + `flatMapLatest`
- Real-time search saat user mengetik tanpa spam request

### ✅ 3. Tiga Model Terpisah (Presentation, Domain, Data)

- **Data Model**: `MovieResponse.kt` (Retrofit) & `MovieEntity.kt` (Room)
- **Domain Model**: `Movie.kt` (pure Kotlin, tanpa dependency Android/library)
- **Presentation Model**: `MovieItem.kt` (UI-specific, berisi formatted string seperti rating "8.5", voteCount "2101 votes", URL gambar lengkap)
- `DataMapper.kt` menangani konversi: Response → Entity → Domain → Presentation

### ✅ 4. Reactive Programming untuk UI

- Search menggunakan `StateFlow` + `debounce(500ms)` + `flatMapLatest` (reactive UI)
- Semua data dari repository menggunakan Coroutine `Flow`
- ViewModel menggunakan `.asLiveData()` untuk konversi Flow ke LiveData
- Repository pattern: network → cache → emit ke UI

### ✅ 5. Dependency Injection dengan Scope Tepat

- `single` — Database, NetworkService, Repository, DataSource (singleton, 1 instance seumur proses)
- `factory` — UseCase (dibuat fresh setiap kali dibutuhkan)
- `viewModel` — ViewModel (lifecycle-aware, destroyed bersama Activity/Fragment)
- Dynamic Feature (Favorite) load module secara lazy via `loadKoinModules` di `onAttach()`

### ✅ 6. Jetpack Navigation Component

- `DynamicNavHostFragment` untuk support Dynamic Feature navigation
- `BottomNavigationView` terintegrasi penuh dengan NavController
- `include-dynamic` di nav_graph.xml untuk navigasi ke Favorite module
- Back stack dikelola otomatis oleh Navigation Component

## Struktur Arsitektur

```
app/                           → Presentation Layer
├── presentation/
│   ├── home/                  → HomeFragment + HomeViewModel
│   ├── search/                → SearchFragment + SearchViewModel (StateFlow + debounce)
│   └── detail/                → DetailActivity + DetailViewModel
└── di/AppModule.kt            → useCaseModule (factory) + viewModelModule (viewModel)

core/                          → Android Library — Data + Domain Layer
├── data/
│   ├── source/local/          → Room Database, MovieEntity, MovieDao, LocalDataSource
│   ├── source/remote/         → Retrofit, MovieResponse, ApiService, RemoteDataSource
│   └── MovieRepository.kt     → Implements IMovieRepository (network-first + cache)
├── domain/
│   ├── model/Movie.kt         → Domain Model (pure Kotlin)
│   ├── repository/IMovieRepository.kt
│   └── usecase/               → MovieUseCase interface + MovieInteractor
├── ui/
│   ├── MovieItem.kt           → Presentation Model + mapper toMovieItem()
│   └── MovieAdapter.kt        → Shared RecyclerView Adapter
├── utils/
│   ├── Resource.kt            → Sealed class (Loading / Success / Error)
│   └── DataMapper.kt          → Mapper antar 3 layer
└── di/CoreModule.kt           → databaseModule + networkModule + repositoryModule

favorite/                      → Dynamic Feature Module (install-time)
├── presentation/
│   ├── FavoriteFragment.kt    → load Koin module di onAttach(), ViewModel manual factory
│   ├── FavoriteViewModel.kt
│   └── FavoriteViewModelFactory.kt
├── di/FavoriteModule.kt       → favoriteModule (loaded on-demand saat fragment attach)
└── res/navigation/            → favorite_nav_graph.xml
```

## Teknologi yang Digunakan

- **Language**: Kotlin
- **Architecture**: Clean Architecture (3 layer: Data, Domain, Presentation)
- **Modularization**: Android Library `core` + Dynamic Feature `favorite`
- **DI**: Koin 3.5.3
- **Reactive**: Coroutine Flow + StateFlow + LiveData
- **Database**: Room (androidx.room)
- **Network**: Retrofit 2 + OkHttp + Gson
- **Image Loading**: Coil 2.5.0
- **Navigation**: Jetpack Navigation Component dengan Dynamic Features
- **UI**: Material Design Components, ViewBinding, Shimmer

## API

- **TheMovieDB** — https://www.themoviedb.org/
- Endpoint yang digunakan:
  - `GET /movie/popular` — Halaman Home
  - `GET /movie/{id}` — Halaman Detail
  - `GET /search/movie` — Halaman Search
