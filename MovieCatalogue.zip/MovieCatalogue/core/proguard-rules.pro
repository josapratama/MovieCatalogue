# Add project specific ProGuard rules here.
-keep class com.dicoding.moviecatalogue.core.data.source.remote.response.** { *; }
-keep class com.dicoding.moviecatalogue.core.data.source.local.entity.** { *; }
-keep class com.dicoding.moviecatalogue.core.domain.model.** { *; }
